package com.account.test.model;

public class AccountTransactions {

	private String accountNumber;

	private String accountName;

	private String valueDate;

	private String currency;

	private String debitCurrency;

	private String creditAmount;

	private String debitorcredit;

	private String transactionNarrative;
	
	public AccountTransactions() {
		
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDebitCurrency() {
		return debitCurrency;
	}

	public void setDebitCurrency(String debitCurrency) {
		this.debitCurrency = debitCurrency;
	}

	public String getCreditAmount() {
		return creditAmount;
	}

	public void setCreditAmount(String creditAmount) {
		this.creditAmount = creditAmount;
	}

	public String getDebitorcredit() {
		return debitorcredit;
	}

	public void setDebitorcredit(String debitorcredit) {
		this.debitorcredit = debitorcredit;
	}

	public String getTransactionNarrative() {
		return transactionNarrative;
	}

	public void setTransactionNarrative(String transactionNarrative) {
		this.transactionNarrative = transactionNarrative;
	}

	@Override
	public String toString() {
		return "AccountTransactions [accountNumber=" + accountNumber + ", accountName=" + accountName + ", valueDate="
				+ valueDate + ", currency=" + currency + ", debitCurrency=" + debitCurrency + ", creditAmount="
				+ creditAmount + ", debitorcredit=" + debitorcredit + ", transactionNarrative=" + transactionNarrative
				+ "]";
	}

}
