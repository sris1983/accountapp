package com.account.test.model;

public class AccountList {
	
	private Long accountNumber;
	
	private String accountName;
	
	private String accountType;
	
	private String balanceDate;
	
	private String currency;
	
	private String openinigBalance;
	
	public AccountList() {
		
	}
		
	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBalanceDate() {
		return balanceDate;
	}

	public void setBalanceDate(String balanceDate) {
		this.balanceDate = balanceDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getOpeninigBalance() {
		return openinigBalance;
	}

	public void setOpeninigBalance(String openinigBalance) {
		this.openinigBalance = openinigBalance;
	}

	@Override
	public String toString() {
		return "AccountList [accountNumber=" + accountNumber + ", accountName=" + accountName + ", accountType="
				+ accountType + ", balanceDate=" + balanceDate + ", currency=" + currency + ", openinigBalance="
				+ openinigBalance + "]";
	}
	
	

}
