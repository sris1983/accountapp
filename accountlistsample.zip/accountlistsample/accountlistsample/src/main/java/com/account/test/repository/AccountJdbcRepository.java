package com.account.test.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.account.test.model.AccountList;
import com.account.test.model.AccountTransactions;

@Repository
public class AccountJdbcRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    static class AccountListRowMapper implements RowMapper<AccountList> {
        public AccountList mapRow(ResultSet rs, int rowNum) throws SQLException {
        	AccountList accountList = new AccountList();
        	accountList.setAccountNumber(rs.getLong("accountNumber"));
        	accountList.setAccountName(rs.getString("accountName"));
        	accountList.setAccountType(rs.getString("accountType"));
        	accountList.setBalanceDate(rs.getString("balanceDate"));
        	accountList.setCurrency(rs.getString("currency"));
        	accountList.setOpeninigBalance(rs.getString("openinigBalance"));
            return accountList;
        }

    }

    public List<AccountList> findAll() {
        return jdbcTemplate.query("select * from accountlist", new AccountListRowMapper());
    }

    public List<AccountTransactions> findById(long accountNumber) {
        return jdbcTemplate.query("select * from accounttransactions where accountNumber=?", new BeanPropertyRowMapper<AccountTransactions>(AccountTransactions.class), accountNumber);
    }
   

    
}
