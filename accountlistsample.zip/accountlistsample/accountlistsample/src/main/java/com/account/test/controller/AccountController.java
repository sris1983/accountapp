package com.account.test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.account.test.model.AccountList;
import com.account.test.model.AccountTransactions;
import com.account.test.repository.AccountJdbcRepository;

/*
 * Controller file for Get all Accounts and Get transaction details.
 */

@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	AccountJdbcRepository accountRepository;

	@GetMapping("/getallaccounts")
	public ResponseEntity<List<AccountList>> getAllAccountsDetails() {
		try {
			List<AccountList> accountlist = new ArrayList<AccountList>();
			accountRepository.findAll().forEach(accountlist::add);
			if (accountlist.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			return new ResponseEntity<>(accountlist, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/accounttransactions/{accountNumber}")
	public ResponseEntity<List<AccountTransactions>> getTransactionsByAccountNumber(@PathVariable("accountNumber") long accountNumber) {
		List<AccountTransactions> accountTransactions = accountRepository.findById(accountNumber);

		if (accountTransactions.size()>0) {
			return new ResponseEntity<>(accountTransactions, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

}
