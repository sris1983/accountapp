insert into accountlist values(585309209,'SGSavings726', 'Savings', '08/11/2018','SGD','84327.21');
insert into accountlist values(791066619,'AuSavings726', 'Savings', '08/11/2018','AUD','88025.93');
insert into accountlist values(321143048,'AuSavings726', 'Current', '08/11/2018','AUD','38327.62');
insert into accountlist values(347786244,'SGSavings726', 'Current', '08/11/2018','SGD','50323.45');
insert into accountlist values(680168913,'SGSavings726', 'Current', '08/11/2018','SGD','84328.53');
insert into accountlist values(136056165,'AuSavings726', 'Savings', '08/11/2018','AUD','84325.65');
insert into accountlist values(453963528,'SGSavings726', 'Savings', '08/11/2018','SGD','84327.51');
insert into accountlist values(334666982,'SGSavings726', 'Savings', '08/11/2018','AUD','78662.58');
insert into accountlist values(347786244,'SGSavings726', 'Current', '08/11/2018','SGD','84327.51');
insert into accountlist values(793949180,'SGSavings726', 'Current', '08/11/2018','SGD','84320.01');
insert into accountlist values(768759901,'SGSavings726', 'Current', '08/11/2018','SGD','5906.55');
insert into accountlist values(847257972,'AuSavings726', 'Current', '08/11/2018','AUD','92561.68');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','92540.68', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','7540.67','7497.82', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','5564.79', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','8136.18', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','9442.46', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','3311.55', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','1905.86', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','197.78', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','8430.49', 'credit', '');
insert into accounttransactions values(1232223212,'Current account', 'Jan122012', 'SGD','9540.67','8.33.68', 'credit', '');




