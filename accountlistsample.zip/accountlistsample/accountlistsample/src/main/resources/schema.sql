create table accountlist
(
   accountNumber integer not null,
   accountName varchar(255) not null,
   accountType varchar(255) not null,
   balanceDate varchar(255) not null,
   currency varchar(255) not null,
   openinigBalance varchar(255) not null   
);

create table accounttransactions
(
   accountNumber integer not null,
   accountName varchar(255) not null,
   valueDate varchar(255) not null,
   currency varchar(255) not null,
   debitCurrency varchar(255) not null,
   creditAmount varchar(255) not null,
   debitorcredit varchar(255) not null,
   transactionNarrative varchar(255) not null   
);

