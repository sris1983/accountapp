Created Spring Boot application with Maven that use Spring Data JPA to interact with H2 database. 

- Configured Spring Data, JPA, Hibernate to work with Database
- Defined Data Models and Repository interfaces
- Created Spring Rest Controller to process HTTP requests
- Used Spring Data JPA to interact with H2 Database

## Run Spring Boot application
```
mvn spring-boot:run
```
h2 db connect details:
url: http://localhost:8080/h2-ui/login.do
JDBC Url: jdbc:h2:mem:testdb

Use below links:
For accountdetails: http://localhost:8080/account/getallaccounts/
For accountTransacations: http://localhost:8080/account/accounttransactions/1232223212

